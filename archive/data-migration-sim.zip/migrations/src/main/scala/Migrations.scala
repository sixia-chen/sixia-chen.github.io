import ch.qos.logback.classic.{Level, Logger}
import optimus.algebra.{Expression, Zero}
import optimus.optimization.model.{MPBinaryVar, MPIntVar}

import scala.collection.{mutable}
import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.HashMap
import scala.collection.mutable.HashSet
import scala.collection.mutable.ArraySeq
//import scala.collection.mutable.ListBuffer
import scala.reflect.ClassTag
import scala.util.Random

object Migrations {
  
  val PRNG = new Random(27)
  implicit class RichRandom(random: Random) {
    def between(lo: Int, up: Int) = { // [inclusive, exclusive)
      random.nextInt(up-lo) + lo
    }
  }

  type Node = Int
  /**
    * This is just an array, except the range of indices can be 0 to 9, or 1 to 10, or 2 to 11, or x to y, for any x <= y
    * @param rng
    * @tparam E
    */
  class Sequence[E <: AnyRef](val rng: Range)(implicit classTag: ClassTag[E]) extends Iterable[E] {
    private val array: Array[E] = if (rng.step != 1) throw new IllegalArgumentException else new Array(rng.length)
    def apply(i: Int): E = array(i-rng.start)
    def update(i: Int, e: E) = array(i-rng.start) = e
    def length = array.length

    override def toString: String = {
      val buf = new StringBuilder
      for { idx <- rng } {
        buf append s"$idx: ${this(idx)}\n"
      }
      buf.toString()
    }

    def copy: Sequence[E] = {
      val clone = new Sequence[E](rng)
      for { i <- rng } {
        clone(i) = this(i)
      }
      clone
    }

    def sortInPlaceBy[B](f: E=>B)(implicit ord: Ordering[B]) = java.util.Arrays.sort(array, ord on f)

    override def iterator: Iterator[E] = array.iterator
  }

  class IntSequence(val rng: Range) extends Iterable[Int] {
    private var array: Array[Int] = if (rng.step != 1) throw new IllegalArgumentException else new Array(rng.length)
    def apply(i: Int): Int = array(i-rng.start)
    def update(i: Int, e: Int) = array(i-rng.start) = e
    def length = array.length

    override def toString: String = {
      val buf = new StringBuilder
      for { idx <- rng } {
        buf append s"$idx: ${this(idx)}\n"
      }
      buf.toString()
    }

    def copy: IntSequence = {
      val clone = new IntSequence(rng)
      for { i <- rng } {
        clone(i) = this(i)
      }
      clone
    }

    def sortInPlaceBy[B](f: Int=>B)(implicit ord: Ordering[B]) = {
      array = array.sortBy(f)
    }

    override def iterator: Iterator[Int] = array.iterator
  }



  class BoolSequence(val rng: Range) extends Iterable[Boolean] {
    private var array: Array[Boolean] = if (rng.step != 1) throw new IllegalArgumentException else new Array(rng.length)
    override def iterator: Iterator[Boolean] = array.iterator
    def apply(i: Int): Boolean = array(i-rng.start)
    def update(i: Int, e: Boolean) = array(i-rng.start) = e
    def length = array.length
  }

  def time(block: => Schedule): Schedule = {
    val t0 = System.currentTimeMillis()
    try {
      val result = block // call-by-name
      //println(s"Found a schedule with ${result.length} stages.")
      result
    } finally {
      val t1 = System.currentTimeMillis()

      //println("Elapsed time: " + (t1 - t0) + " ms")
    }
  }

  /**
    * A file has a source and a destination
    * @param src
    * @param dst
    */
  class File(val src: Int, val dst: Int, val wgt: Int = 1, var start: Option[Int] = None) {
    def incidesWithSrcOf(that: File): Boolean = this.src == that.src || this.dst == that.src
    def incidesWithDstOf(that: File): Boolean = this.dst == that.dst || this.src == that.dst
    def end: Option[Int] = start.map((s: Int) => s + wgt)
    def copy: File = new File(src, dst, wgt, start)

    //override def toString: String = s"${Integer.toHexString(hashCode())}[$src -> $dst]"
    override def toString: String = {
      var buf = new StringBuilder
      buf.append("(")
      buf.append(src + ", ")
      buf.append(dst + ", ")
      buf.append(wgt + ", ")
      buf.append(start.getOrElse("None"))
      buf.append(")")
      buf.toString
    }
  }

  /*
  class WeightedFile(val src: Int, val dst: Int, val wgt: Int, var start: Option[Int]) extends File(src, dst) {
    def end: Option[Int] = start.map((s: Int) => s + wgt)
  }
  */

  object File {
    // nbNodes: number of nodes to choose from
    def random(nbNodes: Int, minW: Int = 0, maxW: Int = 0): File = new File(
      PRNG.between(1, nbNodes+1),
      PRNG.between(1, nbNodes+1),
      PRNG.between(minW, maxW+1))

    def randomBipartite(nbNodesA: Int, nbNodesB: Int, minW: Int = 0, maxW: Int = 0): File = new File(
      PRNG.between(1, nbNodesA+1),
      PRNG.between(nbNodesA+1, nbNodesA+nbNodesB+1),
      PRNG.between(minW, maxW+1))
    /*
    def randomWeighted(nbNodes: Int, minW: Int, maxW: Int): File = new File(
      PRNG.between(1, nbNodes+1),
      PRNG.between(1, nbNodes+1),
      PRNG.between(minW, maxW+1)
    )
    */
  }

  trait InstanceBlueprint {
    def random(N: Int, F: Int): Instance
  }

  def randomNifs(N: Int, minC: Int, maxC: Int): IntSequence =  {
    val nifs = new IntSequence(1 to N) {
      for { n <- 1 to N } {
        //println("minC: " + minC, "maxC: " + maxC)
        this(n) = PRNG.between(minC, maxC+1)
      }
    }
    nifs
  }

  case class OrdinaryBlueprint(minC: Int = 1, maxC: Int = 10, minW: Int = 1, maxW: Int = 1) extends InstanceBlueprint {
    override def random(N: Int, F: Int): Instance = {
      val nifs = randomNifs(N, minC, maxC)
      val nbFiles = F
      //val nbFiles = N * Math.log(N).toInt
      //val nbFiles = N * N
      val files = Stream.continually(File.random(N, minW, maxW)).filter(f => f.src != f.dst).take(nbFiles)
      new Instance(files, nifs)
    }
  }

  case class BipartiteBlueprint(minC: Int = 1, maxC: Int = 10, minW: Int = 1, maxW: Int = 1) extends InstanceBlueprint {
    override def random(N: Int, F: Int): Instance = {
      val halfN = (N / 2).toInt
      val nifs = randomNifs(halfN * 2, minC, maxC)
      val nbFiles = F
      val files = Stream.continually(File.randomBipartite(halfN, halfN, minW, maxW)).filter(f => f.src != f.dst).take(nbFiles)
      new Instance(files, nifs)
    }
  }

  /**
    * An instance is a set of files to migrate, plus the number of network interfaces (nifs) (ie the transmission capacity)
    * of each node.
    * @param files
    * @param nifs
    */
  class Instance(val files: Seq[File], val nifs: IntSequence, var space: IntSequence = null) {
    val nodes = nifs.rng

    if (space==null) {
      space = new IntSequence(nodes)
      for {node <- nodes} {
        space(node) = 1 + Math.max(files.count(_.src == node),
                                   files.count(_.dst == node))
      }
    }

    def shuffle: Instance = new Instance(PRNG.shuffle(files), nifs)

    def augment(sent: Set[File]): Instance = {
      val remainingFiles = for { file <- files
                                 if ! sent.contains(file) }
                             yield file
      val newSpace = space
      new Instance(remainingFiles, nifs, newSpace)
    }

    override def toString: String = {
      val buf = new StringBuilder
      for { file <- files } {
        buf.append("\t")
        buf.append(file)
        buf.append("\n")
      }

      "Space:\n"+space+"\n\nNifs:\n"+nifs+"\n\nFiles:\n"+buf
    }

    def spacify: Instance = new Instance(files, nifs, new IntSequence(nodes) {
      for { node <- nodes } {
        this(node) = Int.MaxValue
      }
    })
  }

  object Instance {
    /*
      N: number of nodes
      F: number of files
      minC: min storage capacity
      maxC: max storage capacity
    */


    def random(N: Int, F: Int, minC: Int = 1, maxC: Int = 10, minW: Int = 1, maxW: Int = 1)  = {
      val nifs = randomNifs(N, minC, maxC)

      val nbFiles = F
      //val nbFiles = N * Math.log(N).toInt
      //val nbFiles = N * N
      val files = Stream.continually(File.random(N, minW, maxW)).filter(f => f.src != f.dst).take(nbFiles)

      new Instance(files, nifs)
    }

    def randomBipartite(A: Int, B: Int, F: Int, minC: Int = 1, maxC: Int = 10, minW: Int = 1, maxW: Int = 1) = {
      val nifs = randomNifs(A + B, minC, maxC)

      val nbFiles = F
      val files = Stream.continually(File.randomBipartite(A, B, minW, maxW)).filter(f => f.src != f.dst).take(nbFiles)

      new Instance(files, nifs)
    }

  }

  /**
    * A schedule is a sequence of stages, where each stage represents the set of files to be migrated at one time.
    * @param plan
    */

  trait Schedule {
    def length: Option[Int]
    def check(instance: Instance): Unit
  }

  case class StartTimeSchedule(plan: Seq[File]) extends Schedule {
    def full: Boolean = !(plan.map(_.start).contains(None))

    override def length: Option[Int] = plan.map(_.end).reduce((a, b) => {
      (a, b) match {
        case (None, _) => None
        case (_, None) => None
        case (Some(a), Some(b)) if a > b => Some(a)
        case (Some(a), Some(b)) if b >= a => Some(b)
      }
    })

    override def check(instance: Instance): Unit = {
      // TODO: Enforce homogeneity constraint
      full
    }
  }

  case class SetSchedule(plan: Seq[Set[File]]) extends Schedule {
    val stages: Seq[Set[File]] = for { fileset <- plan } yield fileset

    //override def length = Some(stages.size)
    override def length: Option[Int] = {
      //println(stages.map(_.map(_.wgt)))
      Some(stages.filter(_.size > 0).map(_.map(_.wgt).max).sum)
    }
    override def check(instance: Instance): Unit = {
      // Checking if each file is only in one stage
      for { file <- instance.files} {
        val timesSent = stages.count(_ contains file)
        require(timesSent == 1, s"file: $file, times sent: $timesSent != 1 {\n\t $toString \n}\n\n${instance.files}")
      }
      // Enforcing space constraint
      //for { node <- instance.nodes
      //      stage <- stages }  require(stage.count(_.src == node) + stage.count(_.dst == node) <= instance.nifs(node))
    }

    def filesForStage(stage: Int) = stages(stage-1)

    def stageForFile(file: File) = stages.find(_.contains(file))

    override def toString: String = {
      val buf = new StringBuilder
      for { (stage, i) <- stages.zipWithIndex } {
        buf.append(i+1)
        buf.append(": ")
        buf.append(stage)
        buf.append("\n")
      }
      return buf.toString
    }

  }

  def bestof(n: Int, scheduler: Instance => Schedule)(instance: Instance): Schedule = time {
    var minlength = Int.MaxValue
    var minSched: Schedule = null
    for { i <- 1 to n } {
      val schedule = scheduler(instance.shuffle)
      if (schedule.length.getOrElse(Int.MaxValue) < minlength) {
        minlength = schedule.length.getOrElse(Int.MaxValue)
        minSched = schedule
      }
    }
    minSched
  }

  def computeSchedule(scheduler: Instance=>Schedule)(instance: Instance): Schedule = {
    val schedule = time {
      scheduler(instance)
    }
    //check(schedule, instance)
    schedule.check(instance)
    schedule
  }

  class Intervals(var intervals: ArrayBuffer[(Int, Int)] = ArrayBuffer[(Int, Int)]()) {
    // Time complexity: O(|I| + |J|)
    // I, J = sets of intervals being compared
    def getIntersection(that: Intervals): Intervals = {
      var aPtr: Int = 0
      var bPtr: Int = 0
      val a = intervals
      val b = that.intervals
      var intersection = ArrayBuffer[(Int, Int)]()
      while (aPtr < a.length && bPtr < b.length) {
        val currentIntersection = (a(aPtr)._1.max(b(bPtr)._1), a(aPtr)._2.min(b(bPtr)._2))
        if (currentIntersection._2 >= currentIntersection._1) {
          intersection += currentIntersection
        }
        if (a(aPtr)._2 < b(bPtr)._2) {
          aPtr = aPtr + 1
        } else {
          bPtr = bPtr + 1
        }
      }
      var i: Int = 0
      while (i < intersection.length - 1) {
        if (intersection(i)._2 >= intersection(i + 1)._1 - 1) {
          intersection(i) = (intersection(i)._1, intersection(i + 1)._2)
          intersection(i + 1) = (-1, -1)
          i = i + 2
        } else {
          i = i + 1
        }
      }
      new Intervals(intersection.filter(_ != (-1, -1)))
    }
    // Time complexity: O(|I|)
    // I = set of intervals
    def getComplement(maxTime: Int): Intervals = {
      if (intervals.length == 0) {
        new Intervals(ArrayBuffer((0, maxTime)))
      } else {
        var complement = ArrayBuffer[(Int, Int)]()
        var i = 0
        for (interval <- intervals) {
          if (interval._1 > i) {
            complement += ((i, interval._1 - 1))
          }
          i = i.max(interval._2)
        }
        complement += ((i, maxTime))
        new Intervals(complement)
      }
    }
    // Time complexity: O(|I|)
    // I = set of intervals
    def getBestFit(minLength: Int): (Int, Int) = {
      intervals.filter((gap) => gap._2 - gap._1 + 1 >= minLength).minBy((gap) => gap._2 - gap._1 + 1)
    }
    def getEarliestFit(minLength: Int): (Int, Int) = {
      intervals.filter((gap) => gap._2 - gap._1 + 1 >= minLength)(0)
    }
    // Time complexity: O(|I|)
    // I = set of intervals
    // O(log|I|) for index search, O(|I|) for insertion
    def addInterval(interval: (Int, Int)): Unit = {
      var left = 0
      var right = intervals.length - 1
      var found = false
      while (left <= right && !found) {
        val mid = (left + right) / 2
        if (interval._1 < intervals(mid)._1) {
          right = mid - 1
        } else if (interval._1 > intervals(mid)._1) {
          left = mid + 1
        } else {
          found = true
        }
      }
      val loc = left.max(right)
      intervals.insert(loc, interval)
    }
    override def toString: String = {
      "[" + intervals.foldLeft("")((a, b) => a + "\n" + b.toString()) + "]"
    }
  }

  def scheduleByTimeTable(instance: Instance, earliest: Boolean = false): StartTimeSchedule = {
    // Get max time
    // Time complexity: O(|E|)
    // E = set of edges (files)
    val maxTime = instance.files.foldLeft(0)((a, b) => a + b.wgt)

    // Initialize node schedules
    // Time complexity: O(|N|)
    // N = set of nodes (disks)
    var nodeSchedules = new Sequence[Intervals](instance.nodes)
    for (i <- instance.nodes) {
      nodeSchedules.update(i, new Intervals(ArrayBuffer[(Int, Int)]()))
    }

    // Sort files by descending weight
    // Time complexity: O(|E| * log|E|)
    val sortedFiles = instance.files.sortBy(-_.wgt)

    var result = new Array[File](sortedFiles.length)
    var i = 0
    // For each file:
    for (file <- sortedFiles) {
      // Get open slots
      // Time complexity: O(|I| + |J|)
      val openSlotsA = nodeSchedules(file.src).getComplement(maxTime)
      val openSlotsB = nodeSchedules(file.dst).getComplement(maxTime)

      // Calculate the intersection of the two nodes' free times
      // Time complexity: O(|I| + |J|)
      val intersection = openSlotsA.getIntersection(openSlotsB)

      // Find the smallest gap where the file could fit
      // Time complexity: O(|I| + |J|)
      // (since the intersection has at most |I| + |J| intervals)
      val bestFit = if (earliest) intersection.getEarliestFit(file.wgt) else intersection.getBestFit(file.wgt)

      // Set node start time to the start of gap
      // Time complexity: O(1)
      result(i) = new File(file.src, file.dst, file.wgt, Some(bestFit._1))
      i += 1
      // Update schedules accordingly
      // Time complexity: O(|I| + |J|)
      nodeSchedules(file.src).addInterval((bestFit._1, bestFit._1 + file.wgt))
      nodeSchedules(file.dst).addInterval((bestFit._1, bestFit._1 + file.wgt))
    }
    StartTimeSchedule(ArrayBuffer(result: _*))
  }

  def scheduleByTimeTableSmall(instance: Instance) = scheduleByTimeTable(instance, false)

  def scheduleByTimeTableEarly(instance: Instance) = scheduleByTimeTable(instance, true)

  // O(|E| * |E| * |E|)
  def scheduleBySeparation(instance: Instance): SetSchedule = {
    var filesLeft = ArrayBuffer[File](instance.files.sortBy(-_.wgt): _*) // O(|E|)
    val plan = new ArrayBuffer[Set[File]]()

    // O(|E| * |E|)
    def makeStage = {
      val currentStage = mutable.Set[File]()
      var availableEdges = ArrayBuffer(filesLeft: _*) // O(|E|)
      // O(|E| * |E|)
      while (availableEdges.size > 0) { // Runs O(|E|) times
        val chosenEdge = availableEdges(0) // O(1)
        // O(|E|)
        availableEdges = availableEdges.filter((e) => {
          !e.incidesWithSrcOf(chosenEdge) && !e.incidesWithDstOf(chosenEdge)
        })
        currentStage += chosenEdge // O(1)
        filesLeft -= chosenEdge // O(|E|)
      }
      plan += currentStage.toSet // O(|E|)
    }

    while (filesLeft.length > 0) { // Runs O(|E|) times
      makeStage
    }

    SetSchedule(plan)
  }

  class AdjacencyList() {
    val adjList = HashMap.empty[Int, HashSet[File]].withDefaultValue(HashSet.empty[File])

    override def toString: String = {
      val buf = new StringBuilder
      for ((node, files) <- adjList) {
        buf.append(node)
        buf.append(": ")
        buf.append(files.toString)
        buf.append("\n")
      }
      buf.toString()
    }

    // O(1)
    def addFile(file: File): Unit = {
      println("Adding file: (" + file.src + ", " + file.dst + ")")
      adjList += (file.src -> (adjList(file.src) + file))
      adjList += (file.dst -> (adjList(file.dst) + file))
      //adjList(file.src) += file
      //adjList(file.dst) += file
      //println(this.toString)
    }

    // O(1)
    def getFile(node: Int): Option[File] = {
      adjList(node).headOption
    }

    def getMaxDegree: Int = {
      var maxDegree = -1
      for ((_, files) <- adjList) {
        if (files.size > maxDegree) {
          maxDegree = files.size
        }
      }
      maxDegree
    }

    // O(1)
    def getAndRemoveFile(node: Int): Option[File] = {
      adjList(node).headOption match {
        case None => None
        case Some(file) => {
          //adjList(file.src) -= file
          //adjList(file.dst) -= file
          println("Removing file: (" + file.src + ", " + file.dst + ")")
          adjList += (file.src -> (adjList(file.src) - file))
          adjList += (file.dst -> (adjList(file.dst) - file))
          if (adjList(file.src).isEmpty) adjList -= file.src
          if (adjList(file.dst).isEmpty) adjList -= file.dst
          Some(file)
        }
      }
    }

    // O(P) (P = path length <= |E|)
    def getAndRemoveHalfPath(start: Int): Seq[File] = {
      var currentNode = start
      val path = ArrayBuffer[File]()
      var running = true
      while (running) {
        getAndRemoveFile(currentNode) match {
          case None => running = false
          case Some(file) => {
            currentNode = if (file.src == currentNode) file.dst else file.src
            path += file
          }
        }
      }
      path
    }

    // O(|P| + |Q|) (P = one path, Q = other path)
    def getAndRemoveFullPath(start: Int): Seq[File] = {
      var pathIn = getAndRemoveHalfPath(start).reverse
      var pathOut = getAndRemoveHalfPath(start)
      pathIn ++ pathOut
    }

    // O(|P| + |Q|)
    def getAndRemoveAnyPath(): Seq[File] = {
      adjList.headOption match {
        case None => ArrayBuffer[File]()
        case Some((node, _)) => {
          getAndRemoveFullPath(node)
        }
      }
    }
  }

  object AdjacencyList {
    // O(|E|)
    /*
    def fromInstance(instance: Instance): AdjacencyList = {
      val adjList = new AdjacencyList()
      for (file <- instance.files) {
        adjList.addFile(file)
      }
      adjList
    }
    */

    //O(|E|)
    def fromFiles(files: Seq[File]): AdjacencyList = {
      val adjList = new AdjacencyList()
      for (file <- files) {
        adjList.addFile(file)
      }
      adjList
    }
  }

  class AdjacencySets() {
    val adjSets = HashMap.empty[Int, HashSet[Int]].withDefaultValue(HashSet.empty[Int])
    
    def addFile(file: File): Unit = {
      adjSets(file.src) += file.dst
      adjSets(file.dst) += file.src
    }
  }

  object AdjacencySets {
    def fromFiles(files: Seq[File]): AdjacencySets = {
      val adjSets = new AdjacencySets()
      for (file <- files) {
        adjSets.addFile(file)
      }
      adjSets
    }
  }

  /*
  // O(|E|)
  def getMaxDegree(files: Seq[File]): Int = {
    val histogram = files.fold(Map.empty[Int, Int])((hist: Map[Int, Int], file: File) =>
      hist + (file.src -> hist.get(file.src).getOrElse(0) + 1) + (file.dst -> hist.get(file.dst).getOrElse(0) + 1)
    )
    histogram.toList.unzip._2.max
  }
  */

  def scheduleByGreedyEuler(files: Seq[File]): Seq[Set[File]] = {
    println("--------------------")
    println("Starting recursive call . . .")
    // Initialize adjacency list (O(|E|))
    val adjList = AdjacencyList.fromFiles(files)
    println(adjList)
    val maxDegree = adjList.getMaxDegree
    println(maxDegree)
    if (maxDegree <= 1) {
      println("Finishing on base case . . .")
      Array[Set[File]](files.toSet)
    } else {
      // Step 1: Partition (O(|E|))
      println("Partitioning edges . . .")
      val abEdges = ArrayBuffer[File]()
      var currentPartition = adjList.getAndRemoveAnyPath()
      while (currentPartition.nonEmpty) {
        abEdges ++= currentPartition
        currentPartition = adjList.getAndRemoveAnyPath()
      }
      val aEdges = ArrayBuffer[File]()
      val bEdges = ArrayBuffer[File]()
      var i = 0
      while (i < abEdges.length) {
        if (i % 2 == 0) {
          aEdges += abEdges(i)
        } else {
          bEdges += abEdges(i)
        }
        i += 1
      }
      println("aEdges: " + aEdges.toString)
      println("bEdges: " + bEdges.toString)
      // Step 2: Recurse
      val a = scheduleByGreedyEuler(aEdges)
      val b = scheduleByGreedyEuler(bEdges)
      val result = (a ++ b).toSeq.sortBy(-_.size)
      println("----------")
      println("a")
      println(a)
      println("b")
      println(b)
      println("result")
      println(result)
      // Step 3: Prune (O(|E|))
      val keep = ArrayBuffer[HashSet[File]]()
      val prune = HashSet.empty[File]
      for (i <- (0 until result.length)) {
        if (i < (2 * maxDegree - 1)) {
          keep += result(i).to[HashSet]
        } else {
          prune ++= result(i)
        }
      }
      println("keep")
      println(keep)
      println("prune")
      println(prune)
      while (keep.length < (2 * maxDegree - 1)) {
        println("Adding empty sets to keep . . .")
        keep += HashSet.empty[File]
      }
      // Step 4: Repair
      // nodesByColor(i) = Set of nodes with an edge of color i
      // node j is missing color i <==> nodesByColor(i) is missing node j
      // Proof: If color i is missing at node j, then no i-colored edge
      // touches j.  Therefore j will not be a node with an edge of color i
      // Similarly, if node j is missing in nodesByColor(i), then that must
      // mean that no edges of that color touch j.  Therefore color i must
      // be missing at node j
      val nodesByColor = ArraySeq.fill[HashSet[Int]](2 * maxDegree - 1)(HashSet.empty[Int])
      for (i <- 0 until (2 * maxDegree - 1)) {
        for (file <- keep(i)) {
          nodesByColor(i) += file.src
          nodesByColor(i) += file.dst
        }
      }
      println("nodesByColor: ")
      println(nodesByColor.toString)
      for (file <- prune) {
        var i = 0
        var running = true
        while (i < (2 * maxDegree - 1) && running) {
          if (!nodesByColor(i)(file.src) && !nodesByColor(i)(file.dst)) {
            keep(i) += file
            nodesByColor(i) += file.src
            nodesByColor(i) += file.dst
            running = false
          }
          i += 1
        }
      }
      println("Finishing on inductive case . . .")
      keep.map(_.toSet).toSeq.filter(_.size > 0)
    }
  }

  def scheduleByGreedyEuler(instance: Instance): SetSchedule = SetSchedule(scheduleByGreedyEuler(instance.files))
/*
  def scheduleByGreedyEuler(instance: Instance): SetSchedule = {
    val d = getMaxDegree(instance)
    if (d <= 1) {
      SetSchedule(Array[Set[File]](instance.files.toSet))
    } else {
      // Convert to adjacency list
      // TO-DO: Improve time complexity by taking advantage of mutability
      val adjList = instance.files.fold(HashMap.empty[Int, HashSet[File]])((acc, file) =>
        acc + (
          (file.src -> acc.get(file.src).getOrElse(HashSet.empty[File]) + file),
          (file.dst -> acc.get(file.dst).getOrElse(HashSet.empty[File]) + file)
        )
      )
      // Partition
      val partitions = ArrayBuffer[Seq[File]]()
      while (adjList.nonEmpty) {
        val nodeA = adjList.head
        val startEdge = nodeA._2.head
        val nodeB = if (startEdge._1 == nodeA._1) startEdge._2 else startEdge._1
        val edgesA = 
      }
    }
  }
*/

  /**
    * Get a schedule for the given instance by greedy matching.
    * @param instance
    * @return
    */
  def scheduleByGreedyMatching(instance: Instance): SetSchedule = {
    val plan = new ArrayBuffer[Set[File]]()
    val alreadyScheduled = mutable.Set[File]()
    val freeSpace = new IntSequence(instance.nodes) {
      for { node <- instance.nodes } {
        this(node) = instance.space(node) - instance.files.count(_.src==node)
      }
    }

    def makeStage = {
      val currentStage = mutable.Set[File]()
      for { file <- instance.files
            if !alreadyScheduled.contains(file)
            if currentStage.count(_ incidesWithSrcOf file) < instance.nifs(file.src)
            if currentStage.count(_ incidesWithDstOf file) < instance.nifs(file.dst)
            if freeSpace(file.dst) > 0} {

        currentStage += file
        freeSpace(file.src) = freeSpace(file.src) + 1
        freeSpace(file.dst) = freeSpace(file.dst) - 1
        alreadyScheduled += file
      }
      plan += currentStage.toSet
    }

    while (alreadyScheduled.size < instance.files.size) {
      makeStage
    }
    SetSchedule(plan)
  }

  def scheduleByGreedyLP(instance: Instance): SetSchedule = {
    var curInstance = instance
    def solveLp: Set[File] = {
      val nodes = curInstance.nodes
      val space = curInstance.space
      val nifs = curInstance.nifs
      val files = curInstance.files

      import optimus.optimization._
      import optimus.optimization.enums.SolverLib
      implicit val model = MPModel(SolverLib.LpSolve)
      val vars = (for { file <- files} yield file -> MPBinaryVar()).toMap

      def initial(node: Int) = files.count(_.src==node)

      def incoming(node: Int) = for { file <- files
                                      if file.dst==node }
                                  yield vars(file)

      def outgoing(node: Int) = for { file <- files
                                      if file.src==node }
                                  yield vars(file)

      def engaging(node: Int) = outgoing(node) ++ incoming(node)


      def sum(xs: Iterable[Expression]): Expression = xs.fold(Zero)((x, y)=>x+y)


      for { node <- nodes } {
        add(sum(engaging(node)) <:= nifs(node))
        add(initial(node) + sum(incoming(node)) - sum(outgoing(node)) <:= space(node))

      }


      maximize(sum(for { file <- files } yield vars(file)))
      try {
        if (start()) {
          return (for { file <- files
                        if vars(file).value.get > 0 } yield file).toSet
        } else {
          throw new NoSuchElementException
        }
      } finally {
        release()
      }
    }

    val rounds = new ArrayBuffer[Set[File]]
    while (curInstance.files.size > 0) {
      val filesForRound = solveLp
      curInstance = curInstance.augment(filesForRound)
      rounds += filesForRound
    }
    SetSchedule(rounds)
  }



  def scheduleByDstSpace(instance: Instance): SetSchedule = {
    import scala.collection.JavaConverters._


    val rounds = new ArrayBuffer[Set[File]]

    val freeSpace: IntSequence = instance.space.copy
    for { f <- instance.files } freeSpace(f.src) = freeSpace(f.src) - 1
    val files = instance.files.toBuffer

    var freeCapacity = instance.nifs.copy

    var currentRound = Set[File]()
    while (files.size > 0) {
      val ascendingFreeSpace: File=>Int = f => -freeSpace(f.dst)
      files.asJava.sort(implicitly[Ordering[Int]] on ascendingFreeSpace)
      val fileToSchedule = files.find(file => freeCapacity(file.src) > 0 && freeCapacity(file.dst) > 0)
      if (fileToSchedule.isDefined) {
        files -= fileToSchedule.get
        freeCapacity(fileToSchedule.get.src) = freeCapacity(fileToSchedule.get.src) - 1
        freeCapacity(fileToSchedule.get.dst) = freeCapacity(fileToSchedule.get.dst) - 1
        freeSpace(fileToSchedule.get.src) = freeSpace(fileToSchedule.get.src) + 1
        freeSpace(fileToSchedule.get.dst) = freeSpace(fileToSchedule.get.dst) - 1
        currentRound = currentRound + fileToSchedule.get
      } else {
        rounds += currentRound
        currentRound = Set[File]()
        freeCapacity = instance.nifs.copy
      }
    }
    rounds += currentRound
    SetSchedule(rounds)
  }


  def scheduleBySpaceAndDegree(instance: Instance): SetSchedule = {
    val rounds = new ArrayBuffer[Set[File]]

    val capacity = instance.nifs
    val freeSpace: IntSequence = instance.space.copy
    for { f <- instance.files } freeSpace(f.src) = freeSpace(f.src) - 1
    val files = instance.files.toBuffer

    //class Connections(val incoming: mutable.Set[File] = mutable.Set(), val outgoing: mutable.Set[File] = mutable.Set())
    val cxns = new Sequence[Connections](instance.nodes)
    for {node <- instance.nodes } cxns(node) = new Connections()
    for { file <- files } {
      cxns(file.src).outgoing += file
      cxns(file.dst).incoming += file
    }

    while (files.size > 0) {
      // Get the degrees of all the nodes
      val degree = new IntSequence(instance.nodes)
      for { f <- files } {
        degree(f.src) = degree(f.src) + 1
        degree(f.dst) = degree(f.dst) + 1
      }
      //sort the nodes by space and degree
      val nodes = new IntSequence(instance.nodes)
      for { n <- nodes.rng } nodes(n) = n
      nodes.sortInPlaceBy(node => (-freeSpace(node), degree(node) * -1.0 / capacity(node)))


      var currentRound = Set[File]()
      val freeCapacity = capacity.copy
      for { node <- nodes } {
        def tryFile(file: File) = {
          if (freeCapacity(file.src) > 0 && freeCapacity(file.dst) > 0 && freeSpace(file.dst) > 0) {
            files -= file
            cxns(file.src).outgoing -= file
            cxns(file.dst).incoming -= file
            freeCapacity(file.src) = freeCapacity(file.src) - 1
            freeCapacity(file.dst) = freeCapacity(file.dst) - 1
            freeSpace(file.src) = freeSpace(file.src) + 1
            freeSpace(file.dst) = freeSpace(file.dst) - 1
            currentRound += file
          }
        }
        for { file <- cxns(node).incoming } tryFile(file)
        for { file <- cxns(node).outgoing } tryFile(file)
      }
      rounds += currentRound
    }
    SetSchedule(rounds)
  }

  /**
    *
    */
  def scheduleByMip(instance: Instance): SetSchedule = {
    print("...")
    import optimus.optimization._
    import optimus.optimization.enums.SolverLib

    def solveLpForSchedule(tf: Int) = {
      print(tf+", ")
      implicit val model = MPModel(SolverLib.LpSolve)
      val vars = (for { t <- 1 to tf
                        file <- instance.files} yield (file, t) -> MPBinaryVar()).toMap

      def initial(node: Int) = instance.files.count(_.src==node)

      def incoming(node: Int, t: Int) = for { (file, stage) <- vars.keys
                                              if file.dst==node && stage==t }
        yield vars((file, stage))

      def outgoing(node: Int, t: Int) = for { (file, stage) <- vars.keys
                                              if file.src==node && stage==t }
        yield vars((file, stage))

      def engaging(node: Int, t: Int) = outgoing(node, t) ++ incoming(node, t)


      def sum(xs: Iterable[Expression]): Expression = xs.fold(Zero)((x, y)=>x+y)

      for { file <- instance.files } {
        add(sum(for { (f, t) <- vars.keys
                      if (f == file) } yield vars((f, t))) := 1)
      }
      for { node <- instance.nodes
            t <- 1 to tf } {
        add(sum(engaging(node, t)) <:= instance.nifs(node))
        add(initial(node) + sum(for { stage <- 1 to t } yield sum(incoming(node, stage)) - sum(outgoing(node, stage))) <:= instance.space(node))

      }

      def filesForStage(t: Int): Seq[File] = for { file <- instance.files
                                                   if vars((file, t)).value.get == 1.0 }
        yield file

      def schedule = SetSchedule(for { t <- 1 to tf }
                                yield filesForStage(t).toSet)

      try {
        if (start()) {
          schedule
        } else {
          throw new NoSuchElementException
        }
      } finally {
        release()
      }
    }


    /*
    var tf = 1
    var ubSched: Schedule = null
    do {
      try {
        ubSched = solveLpForSchedule(tf)
      } catch {
        case _: NoSuchElementException => tf = tf*2
      }
    } while (ubSched == null)


    var ub = ubSched.length
    var lb = ub/2
    while (ub > lb) {
      val m = (lb + ub)/2
      println(s"$lb $m $ub")
      try {
        val midSched = solveLpForSchedule(m)
        ub = m
        ubSched = midSched
      } catch {
        case _: NoSuchElementException => lb = m+1
      }
    }

    ubSched
     */

    var tf = 1
    while (true) try {
      val sched = solveLpForSchedule(tf)
      return sched
    } catch {
      case _: NoSuchElementException => tf = tf + 1
    }
    ???


  }


  class Connections(val incoming: mutable.Set[File] = mutable.Set(), val outgoing: mutable.Set[File] = mutable.Set()) {
    def copy = new Connections(for {c <- incoming} yield c, for {c <- outgoing} yield c)

    override def toString: String =
      s"""incoming: $incoming
         |outgoing: $outgoing
       """.stripMargin
  }

  def scheduleByStructure(instance: Instance): SetSchedule = {
    val nodes = instance.nodes
    val files = mutable.Set(instance.files :_*)
    val space = instance.space
    val c = instance.nifs

    val freeSpace: IntSequence = space.copy
    for { f <- files } freeSpace(f.src) = freeSpace(f.src) - 1


    val cxns = new Sequence[Connections](nodes)
    for {node <- nodes } cxns(node) = new Connections()
    for { file <- files } {
      cxns(file.src).outgoing += file
      cxns(file.dst).incoming += file
    }


    //println("getting cycles...")
    val cycles = getCycles(cxns.copy)
    //println("Got them")
    //println(s"Got cycles: $cycles")
    for { cycle <- cycles
          file <- cycle } files -= file

    //println("making dag...")
    val dag = new Sequence[Connections](nodes)
    for {node <- nodes } dag(node) = new Connections()
    for { file <- files } {
      dag(file.src).outgoing += file
      dag(file.dst).incoming += file
    }

    val cycleInstance = instance.augment(files.toSet)
    //println("schedulinging cycles...")
    val cycleSchedule = scheduleByGreedyMatching(cycleInstance)




    //val dagInstance = instance.augment(cycles)

    val ranks = nodes
    //println("sorting dag...")
    val nodesByRank = toposort(dag)

    //println("scheduling dag...")
    val dagRounds = new ArrayBuffer[Set[File]]()
    while (files.size > 0) {
      val lastSz = files.size
      var currentRound = Set[File]()

      val degree = new IntSequence(instance.nodes)
      for { f <- files } {
        degree(f.src) = degree(f.src) + 1
        degree(f.dst) = degree(f.dst) + 1
      }

      val remainingCapacity = c.copy

      for { rank <- ranks
            node = nodesByRank(rank) } {
        var incoming: Seq[File] = cxns(node).incoming.toSeq.sortBy(file => -degree(file.src))
        //println("scheduling receptions by node " + node)
        while (remainingCapacity(node) > 0 && freeSpace(node) > 0 && incoming.size > 0)  {
          val file = incoming.head
          if (remainingCapacity(file.src) > 0) {
            remainingCapacity(node) -= 1
            remainingCapacity(file.src) -= 1
            files -= file
            cxns(node).incoming -= file
            cxns(file.src).outgoing -= file
            freeSpace(node) -= 1
            freeSpace(file.src) += 1
            currentRound = currentRound + file
          }
          incoming = incoming.tail
        }
      }
      dagRounds += currentRound

      if (files.size == lastSz) {
        println("Instance:\n"+instance)
        println("Cyclic Instance:\n"+cycleInstance)
        println(s"Space:\n$space Free:\n$freeSpace Dag:\n$dag")
        println(s"\n\n\t$files remaining")
        require(files.size < lastSz)
      }
    }

    println("concattenating schedules...")
    SetSchedule(cycleSchedule.stages ++ dagRounds)
  }

  private def getCycles(cxns: Migrations.Sequence[Connections]): Iterable[Iterable[File]] = {
    val cycles = new ArrayBuffer[Iterable[File]]()
    val nodes = cxns.rng

    def dfs(node: Int, edge: File = null, seen: Set[Int] = Set.empty[Int]): Option[(Node, List[File], Boolean)] = {
      //for { i <- 1 to seen.size } print("\t")
      //println(s"[$node  $edge    $seen]")
      if (seen contains node) {
        return Some((node, Nil, false))
      }
      for { e <- cxns(node).outgoing } {
        dfs(e.dst, e, seen + node) match {
          case Some((n, es, true)) => return Some((node, es, true))
          case Some((n, es, false)) if n == node => return Some((n, e::es, true))
          case Some((n, es, false)) => return Some((n, e::es, false))
          case None => {}
        }
      }
      None
    }

    def findCycle: Option[Iterable[File]] = {
      for { root <- nodes } {
        //println("dfs from root "+ root)
        dfs(root) match {
          case Some((_, files, _)) => {
            for { file <- files } {
              cxns(file.src).outgoing -= file
              cxns(file.dst).incoming -= file
            }
            //println(s"one cycle is $files")
            return Some(files)
          }
          case None => {}
        }
      }
      None
    }

    var cycle = findCycle
    while (cycle.isDefined) {
      cycles += cycle.get
      cycle = findCycle
    }

    cycles
  }

  private def toposort(cs: Migrations.Sequence[Migrations.Connections]): IntSequence = {
    val nodes = cs.rng
    val cxns = new Sequence[Connections](nodes)
    for { node <- nodes } {
      cxns(node) = cs(node).copy
    }

    val placed = new BoolSequence(nodes)
    val nodesByRank = new IntSequence(1 to nodes.size)

    var nbPlaced = 0

    def done = nbPlaced == nodes.size
    def place(n: Int) = {
      require(!placed(n))
      placed(n) = true
      nbPlaced += 1
      nodesByRank(nbPlaced) = n
      for { e <- cxns(n).incoming } {
        cxns(e.src).outgoing -= e
      }
    }

    while (!done) {
      var node = nodes.find(!placed(_)).get
      while (!cxns(node).outgoing.isEmpty) {
        val edge = cxns(node).outgoing.head
        node = edge.dst
      }
      place(node)
    }

    nodesByRank
  }


}



object MigrationsApp extends App {
  import Migrations._
  import co.theasi.plotly._

  import org.slf4j.LoggerFactory

  val root = LoggerFactory.getLogger(org.slf4j.Logger.ROOT_LOGGER_NAME).asInstanceOf[Logger]
  root.detachAndStopAllAppenders()

  println("let's go!")
  val algos = Map("GreedyMatching" -> computeSchedule(scheduleByGreedyMatching) _,
                  "GreedyByEdge" -> computeSchedule(scheduleByDstSpace) _,
                  "GreedyByNode" -> computeSchedule(scheduleBySpaceAndDegree) _,
                  "Cycle&Dag" -> computeSchedule(scheduleByStructure) _,
                  "Optimal" -> computeSchedule(scheduleByMip) _ )

  val newAlgos = Map("TimeTable" -> computeSchedule(scheduleByTimeTableSmall) _,
                     "TimeTableEarly" -> computeSchedule(scheduleByTimeTableEarly) _,
                     "MCS" -> computeSchedule(scheduleBySeparation) _,
                     "GreedyEuler" -> computeSchedule(scheduleByGreedyEuler) _)

  /*
    plotName: name of plot
    algos: algorithms to try
    nodeCnts: kth set has nodeCnts(k) nodes
    nbEdges: kth set has nbEdges(nodeCnts(k)) edges
    minC: min storage capacity
    maxC: max storage capacity
    minW: min weight
    maxW: max weight
  */
  //def run(plotName: String, algos: Map[String, Instance=>Schedule], nodeCnts: Seq[Int], nbEdges: Int=>Int, minC: Int, maxC: Int, minW: Int = 1, maxW: Int = 1) = {
  def run(plotName: String, algos: Map[String, Instance=>Schedule], nodeCnts: Seq[Int], nbEdges: Int=>Int, blueprint: InstanceBlueprint) = {
    println(s"[$plotName]")
    // instanceSets: each set has 100 instances.  The number of nodes in each instance
    // of the kth set is nodeCnts(k) and the number of edges is nbEdges(nodeCnts(k))
    val instanceSets = for { n <- nodeCnts } yield for { i <- 1 to 100 } yield blueprint.random(n, nbEdges(n))
    val instances = nodeCnts.zip(instanceSets).toMap
    //val crampedInstances = nodeCnts.zip(instanceSets).toMap
    //val roomyInstances = for { (n, instanceSet) <- crampedInstances } yield n -> instanceSet.map(_.spacify)
    def subrun(subname: String, instances: Map[Int, Seq[Instance]]) = {
      val xAxisOptions = AxisOptions().title("Number of Nodes")
      val yAxisOptions = AxisOptions().title("Average Completion Time")
      var p = Plot()
      var pLine = Plot()
      def marker(name: String) = ScatterOptions().mode(ScatterMode.Marker).name(name)
      def lineMarker(name: String) = ScatterOptions().mode(ScatterMode.Marker, ScatterMode.Line).name(name)
      for { (algname, alg) <- algos } {
        println(s"\n\n$algname\n==============")
        val (sizes, lengths) = (for { n <- nodeCnts
                                      instance <- instances(n) } yield (n, alg(instance).length)).unzip
        /*
        val avgs = for { (n, lens) <- (sizes zip lengths).groupBy(_._1)} yield {
          val lensValid = lens.unzip._2.filter(_ != None)
          val avg = lensValid.map(_.getOrElse(0)).sum * 1.0 / lensValid.size
          avg
        }*/
        val avgs = for { (n, lens) <- (sizes zip lengths).groupBy(_._1)} yield {
          //println(s"\t[$n]")
          for { (_, len) <- lens} {
            //println(s"\t\t$len")
          }
          val lensValid = lens.unzip._2.filter(_ != None)
          // Average length of schedules for size n
          val avg = lensValid.map(_.getOrElse(0)).sum * 1.0 / lensValid.size
          //println(s"\t  ave: ${avg}")
          avg
        }
        //println(sizes)
        //println(nodeCnts)
        //println(avgs)
        p = p.withScatter(sizes, lengths.filter(_ != None).map(_.getOrElse(0)), marker(algname)).xAxisOptions(xAxisOptions).yAxisOptions(yAxisOptions)
        pLine = pLine.withScatter(nodeCnts, avgs, lineMarker(algname))
      }
      var doneDrawing = false
      while (!doneDrawing) {
        try {
          draw(p, plotName + "-" + subname, writer.FileOptions(overwrite = true))
          //draw(pLine, plotName + "-" + subname + "-line", writer.FileOptions(overwrite = true))
        } catch {
          case x: Exception => {
            x.printStackTrace()
            Thread.sleep(1000)
            println("    .... retrying plotly")
          }
        }
        doneDrawing = true
      }
    }
    subrun("test", instances)
    //subrun("constrained", crampedInstances)
    //subrun("unlimited", roomyInstances)
  }
  /*
  run("migration-with-unit-weights", newAlgos, (4 to 100).toList, n=>(n*1.6).toInt, 0, 0, 1, 1)
  run("migration-with-low-weights", newAlgos, (4 to 100).toList, n=>(n*1.6).toInt, 0, 0, 1, 5)
  run("migration-with-med-weights", newAlgos, (4 to 100).toList, n=>(n*1.6).toInt, 0, 0, 1, 10)
  run("migration-with-high-weights", newAlgos, (4 to 100).toList, n=>(n*1.6).toInt, 0, 0, 1, 50)
  */

  run("migration-with-unit-weights", newAlgos, (4 to 100).toList, n=>(n*1.6).toInt, new OrdinaryBlueprint(0, 0, 1, 1)) 
  run("migration-with-low-weights", newAlgos, (4 to 100).toList, n=>(n*1.6).toInt, new OrdinaryBlueprint(0, 0, 1, 5))
  run("migration-with-med-weights", newAlgos, (4 to 100).toList, n=>(n*1.6).toInt, new OrdinaryBlueprint(0, 0, 1, 10))
  run("migration-with-high-weights", newAlgos, (4 to 100).toList, n=>(n*1.6).toInt, new OrdinaryBlueprint(0, 0, 1, 50))

  run("migration-with-unit-weights-bipartite", newAlgos, (4 to 100).toList, n=>(n*1.6).toInt, new BipartiteBlueprint(0, 0, 1, 1))
  run("migration-with-low-weights-bipartite", newAlgos, (4 to 100).toList, n=>(n*1.6).toInt, new BipartiteBlueprint(0, 0, 1, 5))
  run("migration-with-med-weights-bipartite", newAlgos, (4 to 100).toList, n=>(n*1.6).toInt, new BipartiteBlueprint(0, 0, 1, 10))
  run("migration-with-high-weights-bipartite", newAlgos, (4 to 100).toList, n=>(n*1.6).toInt, new BipartiteBlueprint(0, 0, 1, 50))


/*
  run("migration-small-homo", algos-"Optimal", Seq(10, 20, 30, 40, 50), n=>(n*Math.log(n)).toInt, 2, 2)
  run("migration-small-hetero", algos-"Optimal", Seq(10, 20, 30, 40, 50), n=>(n*Math.log(n)).toInt, 1, 4)
  run("migration-medium-homo", algos-"Optimal", Seq(10, 20, 30, 40, 50, 60, 70, 80, 90, 100), n=>n*n, 2, 2)
  run("migration-medium-hetero", algos-"Optimal", Seq(10, 20, 30, 40, 50, 60, 70, 80, 90, 100), n=>n*n, 1, 4)
  run("migration-large-homo", algos-"Optimal", Seq(200, 400, 600, 800, 1000), n=>n*100, 5, 5)
  run("migration-large-hetero", algos-"Optimal", Seq(200, 400, 600, 800, 1000), n=>n*100, 1, 8)
*/
}


object SillyTest extends App {
  import org.slf4j.LoggerFactory
  val root = LoggerFactory.getLogger(org.slf4j.Logger.ROOT_LOGGER_NAME).asInstanceOf[Logger]
  root.detachAndStopAllAppenders()

  import Migrations._

  val instance = Instance.random(5, 7, 2, 2, 1, 7)
  println(instance.toString)
  /*
  val nifs = new Sequence[Int](1 to 3)
  for { i <- 1 to 3 } nifs(i) = 2
  val instance = new Instance( List(new File(1, 2),
                                    new File(1, 2),
                                    new File(3, 1),
                                    new File(3, 1),
                                    new File(2, 3),
                                    new File(2, 3),
                                    new File(1, 2)), nifs = nifs)

   */

  println(instance)

  println("\n\nNaive:\n=====================")
  println(computeSchedule(scheduleByGreedyMatching)(instance))

  println("\n\nEdgeRanking:\n=====================")
  println(computeSchedule(scheduleByDstSpace)(instance))

  println("\n\nNodeRanking:\n=====================")
  println(computeSchedule(scheduleBySpaceAndDegree)(instance))

  //println("\n\nOpt:\n=====================")
  //println(computeSchedule(scheduleByMip)(instance))

  println("\n\nStruct:\n=====================")
  println(computeSchedule(scheduleByStructure)(instance))

  println("\n\nTimeTable:\n=====================")
  println(computeSchedule(scheduleByTimeTableSmall)(instance))

  println("\n\nSeparation:\n=====================")
  println(computeSchedule(scheduleBySeparation)(instance))
}



object PlotTest extends App {



  import co.theasi.plotly._
  import util.Random

  val n = 500

  val xs = (0 until n).map { i => Random.nextDouble }
  val ys0 = (0 until n).map { i => Random.nextDouble + 2.0 }
  val ys1 = (0 until n).map { i => Random.nextDouble - 2.0 }

  val p = Plot()
          .withScatter(xs, ys0, ScatterOptions()
                                .mode(ScatterMode.Marker)
                                .name("Above")
                                //.marker(
                                //  MarkerOptions()
                                //  .size(10)
                                //  .color(152, 0, 0, 0.8)
                                //  .lineWidth(2)
                                //  .lineColor(0, 0, 0)))
                       )
          .withScatter(xs, ys1, ScatterOptions()
                                .mode(ScatterMode.Marker)
                                .name("Below")
                                //.marker(
                                //  MarkerOptions()
                                //  .size(10)
                                //  .color(255, 182, 193, 0.9)
                                //  .lineWidth(2)))
                       )

  draw(p, "styled-scatter", writer.FileOptions(overwrite=true))

}
